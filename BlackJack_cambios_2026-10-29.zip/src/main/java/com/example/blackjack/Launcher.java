package com.example.blackjack;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(BlackJackApplication.class, args);
    }
}
